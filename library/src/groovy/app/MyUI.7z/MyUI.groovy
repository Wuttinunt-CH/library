package app

import com.vaadin.ui.*
import com.vaadin.grails.*
import com.vaadin.terminal.*
import com.vaadin.server.*
import com.vaadin.ui.MenuBar.MenuItem
import com.vaadin.annotations.*
import com.vaadin.ui.Image
import com.vaadin.data.*

import app.MyUI
import library.*

import com.vaadin.ui.themes.ValoTheme
import com.vaadin.ui.themes.Reindeer

/**
 *
 *
 * @author
 */

@Title("ระบบจัดการห้องสมุด")
@Theme("todo")
class MyUI extends UI {

    @Override
    protected void init(VaadinRequest vaadinRequest) {

      Object c = UI.getCurrent().getSession().setAttribute("login","username")

		VerticalLayout layout = new VerticalLayout()

    MenuBar mBar = new MenuBar()
      layout.addComponent(mBar)
        MenuItem a = mBar.addItem("ยืม-คืนหนังสือ", FontAwesome.GROUP,null)
                      a.addItem("ยืมหนังสือ",FontAwesome.PLUS , new MenuBar.Command() {
                        @Override
                        public void menuSelected(MenuItem selectedItem) {
                            BorrowBook borrow = new BorrowBook()
                            layout.addComponent(borrow)
                      }})
                      a.addItem("คืนหนังสือ",FontAwesome.REPLY , new MenuBar.Command() {
                        @Override
                        public void menuSelected(MenuItem selectedItem) {
                            BookReturn returnB = new BookReturn()
                            layout.addComponent(returnB)
                      }})
        MenuItem bookingRoomMenu = mBar.addItem("จองห้องค้นคว้า", FontAwesome.HOME,null)
                        bookingRoomMenu.addItem("จองห้องค้นคว้า",FontAwesome.PLUS, new MenuBar.Command() {
                        @Override
                        public void menuSelected(MenuItem selectedItem) {
			                      
                            Controller bookingRoom = new Controller()
                            this.getSession().setAttribute("Controller", bookingRoom)
                            
                            Reservations1 reservations1 = new Reservations1()
                            layout.addComponent(reservations1)
                            layout.setComponentAlignment(reservations1, Alignment.MIDDLE_CENTER)                           

                            Reservations reservations = new Reservations()
                            layout.addComponent(reservations)
                            layout.setComponentAlignment(reservations, Alignment.MIDDLE_CENTER)
			
                            //layout.setHeight("57%")
                            layout.setWidth("100%")

                            /*VerticalLayout todoLayout = new VerticalLayout()
                            todoLayout.setWidth("50em")  
                            layout.addComponent(todoLayout)   
                            layout.setComponentAlignment(todoLayout,Alignment.MIDDLE_CENTER)*/

                            
                      }})
        MenuItem orderbook = mBar.addItem("สั่งซื้อหนังสือเข้าห้องสมุด", FontAwesome.GROUP,null)
                      orderbook.addItem("สั่งซื้อหนังสือเข้าห้องสมุด",FontAwesome.PLUS , new MenuBar.Command() {
                        @Override
                        public void menuSelected(MenuItem selectedItem) {
                            BookOrder2 order = new BookOrder2()
                            layout.addComponent(order)

                      }}) 

        MenuItem bookdata1 = mBar.addItem("บันทึกข้อมูลหนังสือ", FontAwesome.GROUP,null)
                       bookdata1.addItem("บันทึกข้อมูลหนังสือ",FontAwesome.PLUS , new MenuBar.Command() {
                        @Override
                        public void menuSelected(MenuItem selectedItem) {
                            Bookdata bookdata = new Bookdata()
                            layout.addComponent(bookdata)
                            layout.setWidth("100%")
                      }}) 

        MenuItem boss = mBar.addItem("ยืมคืนอุปกรณ์", FontAwesome.GROUP,null)
                       boss.addItem("ยืมคืนอุปกรณ์",FontAwesome.PLUS , new MenuBar.Command() {
                        @Override
                        public void menuSelected(MenuItem selectedItem) {
                           Controller  bookingReturnEquipment = new Controller()
                            this.getSession().setAttribute("Controller", bookingReturnEquipment)
                            
                            TodoEditboss todoEdit = new TodoEditboss()
                            layout.addComponent(todoEdit)
                            layout.setWidth("100%")
                      }})

     
       

		setContent(layout)
    }
}
